import { writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';

// Fresh wireframe from docs/consulting-hero-brief.txt. No discarded art is read.
const dir = new URL('./', import.meta.url);
const W = 1536, H = 1024, trackWidth = 140;
const P = {
  ink: '#20343B', line: '#87959D', light: '#E8EBED', white: '#FFFFFF',
  aqua: '#247F76', pale: '#EFF8F6', mint: '#D7EFDF', blue: '#1871A8',
  coral: '#FFA68E', mauve: '#AC8B9D', slate: '#707C8B',
};
const radius = 160;
const segments = [
  { kind: 'line', x1: 120, y1: 800, x2: 1120, y2: 800, length: 1000 },
  { kind: 'arc', cx: 1120, cy: 640, a0: Math.PI / 2, direction: -1, length: Math.PI * radius },
  { kind: 'line', x1: 1120, y1: 480, x2: 730, y2: 480, length: 390 },
  { kind: 'arc', cx: 730, cy: 320, a0: Math.PI / 2, direction: 1, length: Math.PI * radius },
  { kind: 'line', x1: 730, y1: 160, x2: 1390, y2: 160, length: 660 },
];
const total = segments.reduce((sum, s) => sum + s.length, 0);
const count = 22;
const tileLength = total / count;
function at(distance) {
  let d = Math.max(0, Math.min(distance, total));
  for (let i = 0; i < segments.length; i++) {
    const s = segments[i];
    if (d <= s.length || i === segments.length - 1) {
      if (s.kind === 'line') {
        const t = d / s.length;
        const dx = s.x2 - s.x1, dy = s.y2 - s.y1;
        return { x: s.x1 + dx * t, y: s.y1 + dy * t, tx: dx / s.length, ty: dy / s.length };
      }
      const angle = s.a0 + s.direction * d / radius;
      return { x: s.cx + radius * Math.cos(angle), y: s.cy + radius * Math.sin(angle), tx: -Math.sin(angle) * s.direction, ty: Math.cos(angle) * s.direction };
    }
    d -= s.length;
  }
  throw new Error('Distance outside route');
}
const f = n => Number(n.toFixed(2));
function interval(start, end) {
  const n = Math.ceil((end - start) / 5);
  return Array.from({ length: n + 1 }, (_, i) => {
    const p = at(start + (end - start) * i / n);
    return `${i ? 'L' : 'M'}${f(p.x)} ${f(p.y)}`;
  }).join('');
}
const path = 'M120 800H1120A160 160 0 0 0 1120 480H730A160 160 0 0 1 730 160H1390';
const checkpoints = [
  { index: 0, id: 'records', label: 'Find revenue leaks', labelX: 200, labelY: 928 },
  { index: 3, id: 'workflow', label: 'Keep deals moving', labelX: 606, labelY: 928 },
  { index: 5, id: 'ai', label: 'Free your team to sell', labelX: 884, labelY: 928 },
  { index: 12, id: 'systems', label: 'Keep every team in sync', labelX: 890, labelY: 345 },
  { index: 19, id: 'reporting', label: 'Decide with confidence', labelX: 1043, labelY: 287 },
];
const checkpointMap = new Map(checkpoints.map(c => [c.index, c]));
const symbol = {
  records: '<path d="M-43-29H5L-12-7V10M-10-1H3" fill="none"/><path d="M-12 19Q-2 29-12 34Q-23 29-12 19Z"/><circle cx="23" cy="-5" r="21"/><path d="M37 11L49 26M13-5H32" fill="none"/>',
  workflow: '<path d="M-45 0H43M26-16L43 0L26 16" fill="none" stroke-width="6"/><path d="M-30-23V-14M-30 14V23M-7-23V-14M-7 14V23" fill="none"/>',
  ai: '<circle cx="-7" cy="-5" r="31"/><path d="M-7-24V-5L8 4" fill="none" stroke-width="5"/><rect x="9" y="7" width="34" height="34" rx="5"/><path d="M16 24L24 32L37 16" fill="none"/>',
  systems: '<path d="M-18-23L-7-10M18-23L7-10M-18 23L-7 10M18 23L7 10" fill="none"/><circle cx="0" cy="0" r="11"/><path d="M-44-34L-23-43V-20L-44-29ZM-39-26L-36-16" fill="none"/><rect x="21" y="-43" width="27" height="28" rx="3"/><path d="M27-29L33-23L42-36" fill="none"/><path d="M-46 33V25A13 13 0 0 1-20 25V33M-46 25V37H-40V25ZM-20 25V37H-26V25Z" fill="none"/><rect x="21" y="15" width="27" height="30" rx="3"/><path d="M27 22H42M28 31H29M38 31H39M28 38H29M38 38H39" fill="none"/>',
  reporting: '<path d="M-22 33V10L21-28M-22 10L-37-14" fill="none" stroke-width="5"/><circle cx="-38" cy="-23" r="10"/><circle cx="24" cy="-25" r="19"/><path d="M13-25L21-17L35-33" fill="none"/>',
  onward: '<path d="M-28 28L28-28M0-28H28V0" stroke-width="9"/>',
};

const tiles = Array.from({ length: count }, (_, i) => {
  const c = checkpointMap.get(i);
  const p = at((i + 0.5) * tileLength);
  const last = i === count - 1;
  const fill = last ? P.blue : c?.id === 'ai' ? P.coral : c ? '#DDEEE9' : i % 2 ? P.white : P.pale;
  const glyph = c ? symbol[c.id] : last ? symbol.onward : '';
  return `<g data-tile="${i}"${c ? ` data-milestone="${c.id}"` : ''}>
    <path d="${interval(i * tileLength, (i + 1) * tileLength)}" fill="none" stroke="${fill}" stroke-width="${trackWidth}" stroke-linecap="butt" stroke-linejoin="round"/>
    ${glyph ? `<g transform="translate(${f(p.x)} ${f(p.y)})" fill="${last ? 'none' : P.white}" stroke="${last ? P.white : P.ink}" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round">${glyph}</g>` : ''}
  </g>`;
}).join('\n');
const divisions = Array.from({ length: count - 1 }, (_, i) => {
  const p = at((i + 1) * tileLength);
  const nx = -p.ty * trackWidth / 2, ny = p.tx * trackWidth / 2;
  return `<path d="M${f(p.x - nx)} ${f(p.y - ny)}L${f(p.x + nx)} ${f(p.y + ny)}"/>`;
}).join('');

function person(id, x, shirt, reading) {
  // Identical head, torso and standing bounds. Details are explicitly unresolved.
  const legs = reading
    ? `<path d="M-24 232L-34 427H-3L15 258M8 232L40 330L73 418L99 408L61 314L30 232"/>
       <path d="M-37 425H-2L10 444H-43ZM75 413L101 403L121 414L91 433Z" fill="white"/>`
    : `<path d="M-27 232L-39 426H-5L1 245L14 426H49L30 232"/>
       <path d="M-41 425H-4L8 444H-47ZM13 425H49L64 444H13Z" fill="white"/>`;
  const arms = reading
    ? `<path d="M-31 98L-66 163L-104 175M31 98L56 170L-35 187" fill="none" stroke-width="18"/>
       <rect x="-112" y="119" width="67" height="88" rx="4" fill="white" stroke-width="2.5"/>
       <path d="M-98 140H-60M-98 155H-66M-98 170H-73" fill="none" stroke-width="2"/>`
    : `<path d="M-31 98L-57 170L-46 217M31 98L72 147L122 178" fill="none" stroke-width="18"/>
       <path d="M116 174L139 187M126 183L142 182" fill="none" stroke-width="8"/>`;
  return `<g id="${id}-placeholder" data-height="438" data-head-width="52" transform="translate(${x} 356)" fill="${P.light}" stroke="${P.line}" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
    <ellipse cx="15" cy="448" rx="73" ry="8" fill="${P.light}" stroke="none"/>
    ${legs}
    <path d="M-31 83Q0 73 31 83L37 232Q0 242-37 232Z" fill="${shirt}" fill-opacity="0.45"/>
    ${arms}
    <path d="M-10 65V82Q0 91 12 82V65"/>
    <ellipse cx="0" cy="38" rx="26" ry="32"/>
  </g>`;
}
const graph = `<g id="conceptual-growth">
  <path d="M120 939C560 928 850 795 1065 572C1222 408 1320 302 1390 230V949H120Z" fill="${P.aqua}" opacity="0.065"/>
  <path d="M120 939C560 928 850 795 1065 572C1222 408 1320 302 1390 230" fill="none" stroke="${P.blue}" stroke-width="5" opacity="0.5"/>
</g>`;
const scene = `${graph}
<g id="board">
  <path d="${path}" transform="translate(0 8)" fill="none" stroke="${P.light}" stroke-width="148" stroke-linecap="butt"/>
  <path d="${path}" fill="none" stroke="${P.ink}" stroke-width="148" stroke-linecap="butt"/>
  ${tiles}
  <g fill="none" stroke="${P.aqua}" stroke-width="2" opacity="0.6">${divisions}</g>
  <path d="M120 730V870M1390 90V230" fill="none" stroke="${P.ink}" stroke-width="4"/>
</g>
<g id="character-placement">${person('nia', 385, P.mint, false)}${person('ravi', 1115, P.mauve, true)}</g>`;

const labels = checkpoints.map((c, i) => {
  const p = at((c.index + 0.5) * tileLength);
  const above = c.labelY < p.y;
  const nearY = above ? p.y - 85 : p.y + 85;
  const endY = above ? c.labelY + ((c.labelLines?.length || 1) - 1) * 23 + 9 : c.labelY - 23;
  return `<g data-review-label="${c.id}">
    <path d="M${f(p.x)} ${f(nearY)}L${c.labelX} ${endY}" stroke="${P.line}" stroke-width="1.5" stroke-dasharray="4 5" fill="none"/>
    <text x="${c.labelX}" y="${c.labelY}" text-anchor="middle" fill="${P.ink}" font-size="20" font-weight="600">${(c.labelLines || [c.label]).map((line, j) => `<tspan x="${c.labelX}" dy="${j ? 23 : 0}">${line}</tspan>`).join('')}</text>
  </g>`;
}).join('\n');
const annotations = `<g id="review-annotations" font-family="sans-serif">
  <text x="80" y="62" fill="${P.ink}" font-size="25" font-weight="600">Hero wireframe 5</text>
  <g id="review-team-detail">
    <text x="82" y="142" fill="${P.ink}" font-size="18" font-weight="600">One customer</text>
    <g fill="none" stroke="${P.line}" stroke-width="1.5">
      <path d="M185 197C225 197 222 230 248 230M375 197C335 197 338 230 312 230M185 280C225 280 222 250 248 250M375 280C335 280 338 250 312 250"/>
      <rect x="248" y="215" width="64" height="50" rx="4" fill="white"/>
    </g>
    <g fill="${P.ink}" text-anchor="middle" font-size="17">
      <text x="140" y="193">Marketing</text><text x="420" y="193">Sales</text>
      <text x="140" y="285">Support</text><text x="420" y="285">Finance</text>
    </g>
    <g fill="none" stroke="${P.ink}" stroke-width="2">
      <circle cx="268" cy="231" r="5"/><path d="M259 251Q260 239 268 239Q276 239 277 251M286 229H302M286 239H298M286 249H302"/>
    </g>
  </g>
  <text x="385" y="333" text-anchor="middle" fill="${P.slate}" font-size="18">Nia</text>
  <text x="1115" y="333" text-anchor="middle" fill="${P.slate}" font-size="18">Ravi</text>
  ${labels}
  <text x="1314" y="56" text-anchor="middle" fill="${P.ink}" font-size="22" font-weight="600">Room to grow</text>
  <path d="M1320 66V80" stroke="${P.line}" stroke-width="1.5" stroke-dasharray="4 5"/>
  <path d="M924 752L1020 570" stroke="${P.line}" stroke-width="1.5" stroke-dasharray="5 6" fill="none"/>
</g>`;
function wrap(body, title, desc) {
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" role="img" aria-labelledby="title desc"><title id="title">${title}</title><desc id="desc">${desc}</desc>${body}</svg>`;
}
const desc = 'A fresh ascending board-game journey over a conceptual growth curve. Five milestones show finding revenue leaks, keeping deals moving, freeing the team to sell, Marketing/Sales/Support/Finance in sync and deciding with confidence. Equal-scale guides reserve Nia and Ravi; character artwork is unresolved.';
writeFileSync(fileURLToPath(new URL('consulting-hero-wireframe-v5-layout.svg', dir)), wrap(scene, 'Consulting hero benefits wireframe 5', desc));
writeFileSync(fileURLToPath(new URL('consulting-hero-wireframe-v5-review.svg', dir)), wrap(scene + annotations, 'Consulting hero annotated benefits wireframe 5', desc));
writeFileSync(fileURLToPath(new URL('consulting-hero-wireframe-v5-notes.txt', dir)), "Messaging and wireframe direction approved by user on 2026-11-03: Looks good. Finished character artwork and installation still require review.\nHeadlines: Find revenue leaks; Keep deals moving; Free your team to sell; Keep every team in sync; Decide with confidence.\nOnward destination: Room to grow.\nThe user-selected headline Free your team to sell is retained exactly.\nKeep every team in sync means Marketing, Sales, Support and Finance stay in sync. All four names remain visible around one shared customer in the review detail. The tile retains campaign, deal, support and finance activity cues.\nAI with human review supports freeing selling time. Integrations support shared context; reporting supports confident decisions.\nClean-up: remove numbering, role explanations, repeated feature captions and the long footer. Retain only concise benefits, department identifiers and character placement names.\nAnnotations are for review only. The layout SVG has no text.\nThe fresh route and equal-scale character placements are unchanged. Discarded hero explorations are not references.\nNothing installed.\n");
console.log(JSON.stringify({ benefitRevision: 5, tiles: count, tileWidth: trackWidth, tileLength: f(tileLength), orderedMilestones: checkpoints.map(c => c.id), identicalCharacterBounds: true, installed: false }));
